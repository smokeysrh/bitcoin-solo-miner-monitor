<template>
  <v-app>
    <v-navigation-drawer
      v-if="!isSetupRoute"
      v-model="drawer"
      app
      :temporary="mobile"
      :scrim="mobile"
      class="sidebar-below-header"
      @click:outside="drawer = false"
    >
      <v-list-item>
        <template #prepend>
          <BitcoinLogo 
            size="md" 
            variant="default" 
            :animated="false"
            aria-label="Bitcoin Solo Miner Monitor Logo"
            alt-text="Bitcoin Logo"
            class="mr-3"
          />
        </template>
        <v-list-item-title class="text-h6">
          Bitcoin Solo Miner Monitor
        </v-list-item-title>
        <v-list-item-subtitle>
          Monitor your mining fleet
        </v-list-item-subtitle>
      </v-list-item>

      <v-divider></v-divider>

      <v-list
        dense
        nav
      >
        <v-list-item
          v-for="item in menuItems"
          :key="item.title"
          :prepend-icon="item.icon"
          @click="navigateToPage(item.to)"
          link
        >
          <v-list-item-title>{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
      
      <template #append>
        <div class="pa-2">
          <v-btn
            block
            color="primary"
            @click="navigateToMinersPage"
          >
            <template #prepend>
              <v-icon>mdi-plus</v-icon>
            </template>
            Add Miner
          </v-btn>
        </div>
      </template>
    </v-navigation-drawer>

    <v-app-bar v-if="!isSetupRoute" app class="app-header-fixed">
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>
      <BitcoinLogo 
        size="sm" 
        variant="default" 
        :animated="false"
        aria-label="Bitcoin Solo Miner Monitor Logo"
        alt-text="Bitcoin Logo"
        class="ml-4 mr-3"
      />
      <v-toolbar-title>{{ currentPageTitle }}</v-toolbar-title>
      <v-spacer></v-spacer>
      
      <!-- WebSocket Connection Status -->
      <v-chip
        :color="connectionStatusColor"
        size="small"
        class="mr-2"
      >
        <v-icon start size="small">{{ connectionStatusIcon }}</v-icon>
        {{ connectionStatusText }}
      </v-chip>
      
      <v-btn 
        icon 
        @click="refreshData"
        :loading="refreshing"
        :disabled="refreshing"
        :title="refreshing ? 'Refreshing data...' : 'Refresh all data'"
      >
        <v-icon :class="{ 'refresh-spinning': refreshing }">mdi-refresh</v-icon>
      </v-btn>
      <v-btn 
        icon 
        @click="checkForUpdates"
        :loading="checkingUpdates"
        :disabled="checkingUpdates"
        :title="checkingUpdates ? 'Checking for updates...' : 'Check for updates'"
      >
        <v-icon>mdi-download</v-icon>
      </v-btn>
      <v-btn icon @click="openSettingsDialog">
        <v-icon>mdi-cog</v-icon>
      </v-btn>
    </v-app-bar>

    <v-main :class="{ 'setup-main': isSetupRoute }">
      <v-container v-if="!isSetupRoute" fluid>
        <router-view />
      </v-container>
      <router-view v-else />
    </v-main>



    <!-- Settings Dialog -->
    <v-dialog
      v-model="settingsDialog"
      max-width="500px"
    >
      <v-card>
        <v-card-title>
          Settings
        </v-card-title>
        <v-card-text>
          <v-form ref="settingsForm" v-model="settingsFormValid">
            <v-text-field
              v-model="settings.polling_interval"
              label="Polling Interval (seconds)"
              type="number"
              required
              :rules="[
                v => !!v || 'Polling interval is required',
                v => v >= 5 || 'Polling interval must be at least 5 seconds'
              ]"
            ></v-text-field>
            <v-text-field
              v-model="settings.refresh_interval"
              label="UI Refresh Interval (seconds)"
              type="number"
              required
              :rules="[
                v => !!v || 'Refresh interval is required',
                v => v >= 1 || 'Refresh interval must be at least 1 second'
              ]"
            ></v-text-field>
            <v-text-field
              v-model="settings.chart_retention_days"
              label="Chart Data Retention (days)"
              type="number"
              required
              :rules="[
                v => !!v || 'Chart retention is required',
                v => v >= 1 || 'Chart retention must be at least 1 day'
              ]"
            ></v-text-field>
            <v-select
              v-model="settings.theme"
              :items="[{title: 'Dark', value: 'dark'}, {title: 'Light', value: 'light'}]"
              label="Theme"
              item-title="title"
              item-value="value"
            ></v-select>
          </v-form>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            variant="text"
            @click="settingsDialog = false"
          >
            Cancel
          </v-btn>
          <v-btn
            color="primary"
            variant="text"
            @click="saveSettings"
            :disabled="!settingsFormValid"
            :loading="settingsLoading"
          >
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Snackbar for notifications -->
    <v-snackbar
      v-model="snackbar.show"
      :color="snackbar.color"
      :timeout="snackbar.timeout"
      location="bottom center"
      :multi-line="false"
      class="global-snackbar"
      app
    >
      {{ snackbar.text }}
      <template #actions>
        <v-btn
          variant="text"
          @click="snackbar.show = false"
        >
          Close
        </v-btn>
      </template>
    </v-snackbar>

    <!-- Update Notification -->
    <UpdateNotification />

    <!-- Footer with donation address -->
    <v-footer v-if="!isSetupRoute" class="pa-2 footer-fixed">
      <v-container fluid>
        <v-row align="center" justify="space-between">
          <v-col cols="auto">
            <span class="text-caption text-medium-emphasis">
              Bitcoin Solo Miner Monitor v0.9.1
            </span>
          </v-col>
          <v-col cols="auto" class="text-center">
            <span class="text-caption text-medium-emphasis">
              If you find value in this app, please consider leaving a tip! 
              <span 
                class="donation-address" 
                @click="copyDonationAddress"
                title="Click to copy address to clipboard"
              >
                bc1qnce06pg2gqewjvjmfavwrjt5f4zc37k5d26c6e
              </span>
            </span>
          </v-col>
          <v-col cols="auto">
            <span class="text-caption text-medium-emphasis">
              Est. 1986
              <span class="gaming-hint easter-egg-hint" title="Patterns from gaming's golden age still hold power">🎮</span>
            </span>
          </v-col>
        </v-row>
      </v-container>
    </v-footer>
  </v-app>
</template>

<script>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useDisplay } from 'vuetify'
import { useMinersStore } from './stores/miners'
import { useSettingsStore } from './stores/settings'
import { useAlertsStore } from './stores/alerts'
import { isFirstRun, getDiscoveredMiners, getInitialRoute } from './services/firstRunService'
import { connectionStatus, forceReconnect } from './services/websocket'
import { useEasterEgg } from './composables/useEasterEgg'
import { useUpdateChecker } from './composables/useUpdateChecker'
import { useClipboard } from './composables/useClipboard'
import { useGlobalSnackbar } from './composables/useGlobalSnackbar'
import BitcoinLogo from './components/BitcoinLogo.vue'
import UpdateNotification from './components/UpdateNotification.vue'


export default {
  name: 'App',
  
  components: {
    BitcoinLogo,
    UpdateNotification
  },
  
  setup() {
    const route = useRoute()
    const router = useRouter()
    const minersStore = useMinersStore()
    const settingsStore = useSettingsStore()
    const alertsStore = useAlertsStore()
    const { mobile } = useDisplay()
    
    // Initialize easter egg
    const easterEgg = useEasterEgg()
    
    // Initialize clipboard functionality
    const clipboard = useClipboard()
    
    // Initialize global snackbar
    const { snackbar, showSnackbar } = useGlobalSnackbar()
    
    // Initialize update checker
    let checkUpdates, checkingUpdates
    try {
      const updateChecker = useUpdateChecker()
      checkUpdates = updateChecker.checkForUpdates
      checkingUpdates = updateChecker.isChecking
    } catch (error) {
      console.error('Failed to initialize update checker:', error)
      // Provide fallback values
      checkUpdates = async () => { console.warn('Update checker not available') }
      checkingUpdates = ref(false)
    }
    
    // Navigation drawer state - responsive behavior
    const drawer = ref(false)
    
    // Watch for screen size changes and adjust drawer accordingly
    watch(mobile, (isMobile) => {
      if (!isMobile) {
        // On desktop, keep drawer open by default
        drawer.value = true
      } else {
        // On mobile, close drawer to save space
        drawer.value = false
      }
    }, { immediate: true })
    
    // Check for UI mode preference
    const uiMode = ref(localStorage.getItem('uiMode') || 'advanced')
    
    // Watch for localStorage changes to uiMode
    const updateUIMode = () => {
      const newMode = localStorage.getItem('uiMode') || 'advanced'
      if (uiMode.value !== newMode) {
        uiMode.value = newMode
      }
    }
    
    // Listen for storage events (when localStorage is changed from other tabs/components)
    window.addEventListener('storage', updateUIMode)
    
    // Also watch for route changes to update UI mode if needed
    watch(() => route.path, () => {
      updateUIMode()
    })
    
    // Menu items
    const menuItems = computed(() => {
      const items = [
        { 
          title: 'Dashboard', 
          icon: 'mdi-view-dashboard', 
          to: uiMode.value === 'simple' ? '/dashboard-simple' : '/' 
        },
        { title: 'Miners', icon: 'mdi-server', to: '/miners' },
        { title: 'Analytics', icon: 'mdi-chart-line', to: '/analytics' },
        { title: 'Network', icon: 'mdi-network', to: '/network' },
        { title: 'Settings', icon: 'mdi-cog', to: '/settings' },
        { title: 'About', icon: 'mdi-information', to: '/about' },
      ]
      
      return items
    })
    
    // Current page title
    const currentPageTitle = computed(() => {
      const currentRoute = route.path
      const items = menuItems.value
      if (!Array.isArray(items)) return 'Bitcoin Solo Miner Monitor'
      const currentMenuItem = items.find(item => item.to === currentRoute)
      return currentMenuItem ? currentMenuItem.title : 'Bitcoin Solo Miner Monitor'
    })
    
    // Check if current route is setup
    const isSetupRoute = computed(() => {
      return route.path === '/setup'
    })
    

    
    // Settings dialog
    const settingsDialog = ref(false)
    const settingsFormValid = ref(true) // Initialize as true since we load valid settings
    const settingsForm = ref(null)
    const settings = ref({
      polling_interval: 30,
      refresh_interval: 10,
      chart_retention_days: 30
    })
    
    // Computed property for settings loading state
    const settingsLoading = computed(() => {
      return settingsStore?.loading || false
    })
    

    
    // Refresh state
    const refreshing = ref(false)
    
    // Snackbar is now handled by the global composable
    
    // Methods
    const navigateToMinersPage = () => {
      // Only close drawer on mobile devices after navigation
      if (mobile.value) {
        drawer.value = false
      }
      router.push('/miners')
    }
    
    const navigateToPage = (path) => {
      // Only close drawer on mobile devices after navigation
      if (mobile.value) {
        drawer.value = false
      }
      router.push(path)
    }
    
    const openSettingsDialog = () => {
      // Load current settings from store
      settings.value = {
        polling_interval: settingsStore.settings.polling_interval || 30,
        refresh_interval: settingsStore.settings.refresh_interval || 10,
        chart_retention_days: settingsStore.settings.chart_retention_days || 30,
        theme: settingsStore.settings.theme || 'dark'
      }
      console.log('Opening settings dialog with current settings:', settings.value)
      settingsDialog.value = true
      
      // Ensure form validation is triggered after dialog opens
      setTimeout(() => {
        if (settingsForm.value) {
          settingsForm.value.validate()
        }
      }, 100)
    }
    
    const saveSettings = async () => {
      console.log('saveSettings method called!')
      console.log('settingsFormValid:', settingsFormValid.value)
      console.log('settingsStore.loading:', settingsStore?.loading)
      
      if (settingsStore?.loading) {
        console.log('Settings save already in progress, skipping...')
        return
      }
      
      try {
        // Convert string values to appropriate types before saving
        const settingsToSave = {
          ...settings.value,
          polling_interval: parseInt(settings.value.polling_interval) || 30,
          refresh_interval: parseInt(settings.value.refresh_interval) || 10,
          chart_retention_days: parseInt(settings.value.chart_retention_days) || 30
        }
        
        console.log('Saving settings:', settingsToSave)
        await settingsStore.updateSettings(settingsToSave)
        
        // Auto-close dialog on successful save
        settingsDialog.value = false
        
        // Show success notification
        showSnackbar('Settings saved successfully', 'success')
        
        console.log('Settings saved and applied successfully')
      } catch (error) {
        console.error('Error saving settings:', error)
        showSnackbar(`Error saving settings: ${error.message}`, 'error')
      }
    }
    
    const refreshData = async () => {
      if (refreshing.value) {
        console.log('Refresh already in progress, skipping...')
        return
      }
      
      try {
        refreshing.value = true
        const currentPath = route.path
        console.log('Starting data refresh for current page:', currentPath)
        
        // Handle WebSocket reconnection for disconnected states
        if (connectionStatus.value === 'disconnected' || connectionStatus.value === 'error') {
          console.log('Refresh: WebSocket disconnected, forcing reconnection...')
          showSnackbar('Reconnecting...', 'warning')
          
          try {
            forceReconnect()
            
            // Wait for reconnection to start with timeout
            let reconnectTimeout = 0
            const maxReconnectWait = 2000 // 2 seconds max wait
            
            while (connectionStatus.value === 'disconnected' && reconnectTimeout < maxReconnectWait) {
              await new Promise(resolve => setTimeout(resolve, 100))
              reconnectTimeout += 100
            }
            
            if (connectionStatus.value === 'connecting' || connectionStatus.value === 'reconnecting') {
              console.log('WebSocket reconnection initiated successfully')
            } else {
              console.warn('WebSocket reconnection may have failed, continuing with data refresh')
            }
          } catch (reconnectError) {
            console.error('Error during WebSocket reconnection:', reconnectError)
            showSnackbar('Reconnection failed, refreshing data only', 'warning')
          }
        }
        
        // Determine what to refresh based on current route
        const refreshPromises = []
        
        // Route-specific refresh logic
        if (currentPath === '/' || currentPath === '/dashboard-simple' || 
            currentPath === '/miners' || currentPath === '/network' || 
            currentPath === '/analytics' || currentPath.startsWith('/miners/')) {
          // Pages that display miner data - use the refresh endpoint
          console.log('Refreshing miners data via refresh endpoint...')
          refreshPromises.push(
            minersStore.refreshMiners().catch(error => {
              console.error('Failed to refresh miners:', error)
              console.warn('Miners refresh failed, continuing with other data')
            })
          )
        }
        
        // Settings page - refresh settings
        if (currentPath === '/settings') {
          console.log('Refreshing settings data...')
          refreshPromises.push(
            settingsStore.fetchSettings().catch(error => {
              console.error('Failed to refresh settings:', error)
              console.warn('Settings refresh failed')
            })
          )
        }
        
        // Always refresh alerts as they may appear across pages
        console.log('Refreshing alerts data...')
        refreshPromises.push(
          alertsStore.fetchAlerts().catch(error => {
            console.error('Failed to refresh alerts:', error)
            console.warn('Alerts refresh failed')
          })
        )
        
        // If no specific refresh actions were added, default to refreshing miners
        if (refreshPromises.length === 1) { // Only alerts was added
          console.log('No specific page refresh, defaulting to miners refresh...')
          refreshPromises.unshift(
            minersStore.refreshMiners().catch(error => {
              console.error('Failed to refresh miners:', error)
              console.warn('Miners refresh failed')
            })
          )
        }
        
        // Execute all refresh operations with timeout
        const refreshTimeout = 10000 // 10 seconds timeout
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Refresh operation timed out')), refreshTimeout)
        })
        
        let refreshResults
        try {
          refreshResults = await Promise.race([
            Promise.allSettled(refreshPromises),
            timeoutPromise
          ])
        } catch (timeoutError) {
          console.error('Refresh operation timed out:', timeoutError)
          throw new Error('Refresh timed out - please try again')
        }
        
        // Log results
        let successCount = 0
        let failureCount = 0
        refreshResults.forEach((result, index) => {
          if (result.status === 'rejected') {
            console.warn(`Refresh operation ${index} failed:`, result.reason)
            failureCount++
          } else {
            console.log(`Refresh operation ${index} succeeded`)
            successCount++
          }
        })
        
        // Show appropriate message based on results
        if (successCount > 0 && failureCount === 0) {
          if (connectionStatus.value === 'connected') {
            showSnackbar('Data refreshed successfully', 'success')
          } else if (connectionStatus.value === 'connecting' || connectionStatus.value === 'reconnecting') {
            showSnackbar('Data refreshed, reconnecting...', 'info')
          } else {
            showSnackbar('Data refreshed (offline mode)', 'warning')
          }
        } else if (successCount > 0 && failureCount > 0) {
          showSnackbar('Data partially refreshed', 'warning')
        } else {
          showSnackbar('Refresh failed', 'error')
        }
        
      } catch (error) {
        console.error('Error during data refresh:', error)
        showSnackbar(`Refresh failed: ${error.message}`, 'error')
      } finally {
        refreshing.value = false
        console.log('Data refresh completed')
      }
    }
    
    // showSnackbar is now provided by the global composable
    
    const copyDonationAddress = async () => {
      try {
        const result = await clipboard.copyDonationAddress()
        
        if (result.success) {
          showSnackbar(result.message, 'success')
        } else {
          showSnackbar(result.message, 'error')
        }
      } catch (error) {
        console.error('Error copying donation address:', error)
        showSnackbar('Failed to copy donation address. Please copy manually.', 'error')
      }
    }
    
    const checkForUpdates = async () => {
      try {
        await checkUpdates(true) // Force refresh
        showSnackbar('Update check completed', 'info')
      } catch (error) {
        showSnackbar(`Update check failed: ${error.message}`, 'error')
      }
    }
    
    const addDiscoveredMiners = async () => {
      // Temporarily disabled to prevent connection timeouts during testing phase
      console.log('addDiscoveredMiners disabled during testing phase to prevent unresponsiveness')
      
      // Clear any existing discovered miners to prevent future issues
      localStorage.removeItem('discoveredMiners')
      console.log('Cleared discovered miners from localStorage')
      
      return
      
      /* Original implementation - re-enable after testing phase
      try {
        const discoveredMiners = getDiscoveredMiners()
        console.log('Discovered miners from installer:', discoveredMiners)
        
        if (discoveredMiners && discoveredMiners.length > 0) {
          // Check if these miners are already added
          // const currentMiners = minersStore.miners // TEMPORARILY DISABLED - PINIA ISSUE
          
          for (const discoveredMiner of discoveredMiners) {
            // Check if miner already exists (by IP address)
            const existingMiner = currentMiners.find(m => m.ip_address === discoveredMiner.ip)
            
            if (!existingMiner) {
              console.log(`Adding discovered miner: ${discoveredMiner.name} (${discoveredMiner.ip})`)
              
              try {
                // await minersStore.addMiner({ // TEMPORARILY DISABLED - PINIA ISSUE
                  type: discoveredMiner.type,
                  ip_address: discoveredMiner.ip,
                  // Don't include port field to use default port
                  name: discoveredMiner.name
                })
                
                console.log(`Successfully added miner: ${discoveredMiner.name}`)
              } catch (error) {
                console.warn(`Failed to add miner ${discoveredMiner.name}:`, error.message)
              }
            } else {
              console.log(`Miner ${discoveredMiner.name} already exists, skipping`)
            }
          }
          
          // Clear discovered miners from localStorage after adding them
          localStorage.removeItem('discoveredMiners')
          console.log('Cleared discovered miners from localStorage')
          
          // Show success message
          showSnackbar(`Added ${discoveredMiners.length} miners from installer`, 'success')
        }
      } catch (error) {
        console.error('Error adding discovered miners:', error)
        showSnackbar('Error adding discovered miners', 'error')
      }
      */
    }
    
    // Lifecycle hooks - MINIMAL FOR PHASE 1 TESTING
    onMounted(async () => {
      // Check if this is the first run and redirect accordingly
      console.log('=== APP MOUNTED - FIRST RUN CHECK ===')
      console.log('localStorage firstRunComplete:', localStorage.getItem('firstRunComplete'))
      console.log('Current route path:', route.path)
      
      try {
        console.log('About to call isFirstRun()...')
        const firstRun = await isFirstRun()
        console.log('isFirstRun() returned:', firstRun, 'type:', typeof firstRun)
        
        if (firstRun === true) {
          console.log('First run detected, redirecting to setup')
          await router.push('/setup')
        } else {
          console.log('Not a first run, current path:', route.path)
          // Not a first run, ensure we're not on the setup page
          if (route.path === '/setup') {
            console.log('On setup page but first run is complete, redirecting...')
            // Redirect to appropriate dashboard based on user preferences
            const initialRoute = getInitialRoute()
            console.log('Initial route determined:', initialRoute)
            await router.push(initialRoute)
            console.log('Redirect completed to:', initialRoute)
          } else {
            console.log('Not on setup page, staying on current route:', route.path)
          }
        }
      } catch (error) {
        console.error('Error in first run check:', error)
      }
      

      
      console.log('=== APP MOUNTED COMPLETE ===')
    })
    
    // Cleanup event listeners
    onUnmounted(() => {
      window.removeEventListener('storage', updateUIMode)
    })
    
    // Original complex onMounted logic (disabled for Phase 1):
    /*
    onMounted(async () => {
      console.log('=== APP MOUNTED - FIRST RUN CHECK ===')
      console.log('localStorage firstRunComplete:', localStorage.getItem('firstRunComplete'))
      console.log('Current route path:', route.path)
      
      console.log('✅ DOM ready, starting first run check...')
      
      try {
        console.log('✅ About to call isFirstRun()...')
        const firstRun = await isFirstRun()
        console.log('✅ isFirstRun() completed, returned:', firstRun, 'type:', typeof firstRun)
        
        if (firstRun === true) {
          console.log('✅ First run detected, redirecting to setup')
          console.log('Current route before redirect:', route.path)
          
          try {
            console.log('✅ About to call router.push("/setup")...')
            await router.push('/setup')
            console.log('✅ Router push completed successfully')
            console.log('New route after redirect:', route.path)
          } catch (routerError) {
            console.error('❌ Router push failed:', routerError)
          }
          console.log('✅ Setup redirect complete, exiting onMounted')
          return
        } else {
          console.log('❌ Not a first run, will initialize normal app')
        }
      } catch (error) {
        console.error('❌ Error checking first run status:', error)
        console.log('Falling back to normal app initialization')
      }
      
      console.log('=== INITIALIZING NORMAL APP ===')
      console.log('Final route path:', route.path)
      
      console.log('API calls disabled during Phase 1 testing')
      console.log('This prevents hanging on backend connections during setup wizard testing')
      
      console.log('WebSocket connection disabled during Phase 1 testing to prevent browser unresponsiveness')
      
      console.log('✅ App initialization complete - onMounted finished')
      console.log('=== END APP MOUNTED ===')
      
      setTimeout(() => {
        console.log('✅ 5 seconds after mount - page should be responsive')
      }, 5000)
    })
    */
    
    // WebSocket connection status
    const connectionStatusColor = computed(() => {
      switch (connectionStatus.value) {
        case 'connected': return 'success'
        case 'connecting': 
        case 'reconnecting': return 'warning'
        case 'disconnected': return 'error'
        case 'error': return 'error'
        default: return 'info'
      }
    })
    
    const connectionStatusIcon = computed(() => {
      switch (connectionStatus.value) {
        case 'connected': return 'mdi-wifi'
        case 'connecting': 
        case 'reconnecting': return 'mdi-wifi-sync'
        case 'disconnected': return 'mdi-wifi-off'
        case 'error': return 'mdi-wifi-alert'
        default: return 'mdi-wifi-off'
      }
    })
    
    const connectionStatusText = computed(() => {
      switch (connectionStatus.value) {
        case 'connected': return 'Connected'
        case 'connecting': return 'Connecting'
        case 'reconnecting': return 'Reconnecting'
        case 'disconnected': return 'Disconnected'
        case 'error': return 'Connection Error'
        default: return 'Unknown'
      }
    })


    
    return {
      drawer,
      mobile,
      menuItems,
      currentPageTitle,
      isSetupRoute,
      settingsDialog,
      settingsFormValid,
      settingsForm,
      settings,
      settingsStore, // Add settingsStore to fix the loading state access
      settingsLoading, // Add computed loading state
      refreshing,
      snackbar,
      navigateToMinersPage,
      navigateToPage,
      openSettingsDialog,
      saveSettings,
      refreshData,
      copyDonationAddress,
      checkForUpdates,
      connectionStatusColor,
      connectionStatusIcon,
      connectionStatusText,
      checkingUpdates,
      
      // Easter egg (for development debugging)
      easterEgg
    }
  }
}
</script>

<style scoped>
/* App bar fixed positioning */
.app-header-fixed {
  position: sticky !important;
  top: 0 !important;
  z-index: 1010 !important;
  width: 100% !important;
  transform: none !important;
}

/* Ensure app bar stays above all content */
:deep(.v-app-bar.app-header-fixed) {
  position: sticky !important;
  top: 0 !important;
  z-index: 1010 !important;
  width: 100% !important;
  transform: none !important;
}

/* Force sticky positioning for Vuetify app bar */
:deep(.v-app-bar) {
  position: sticky !important;
  top: 0 !important;
  z-index: 1010 !important;
}

/* Ensure navigation drawer stays below header but above content */
:deep(.v-navigation-drawer) {
  z-index: 1005 !important;
}

/* Ensure navigation drawer overlay works properly */
:deep(.v-overlay--active) {
  z-index: 1004 !important;
}

/* Position sidebar below the sticky header */
:deep(.sidebar-below-header) {
  top: 64px !important;
  height: calc(100vh - 64px) !important;
  z-index: 1005 !important;
}

/* Ensure sidebar content starts below header */
:deep(.sidebar-below-header .v-navigation-drawer__content) {
  padding-top: 0 !important;
}

/* Ensure drawer is accessible from any scroll position */
:deep(.v-navigation-drawer.v-navigation-drawer--temporary) {
  position: fixed !important;
  z-index: 1005 !important;
}

/* Setup route styling - remove all padding and margins for fullscreen wizard */
.setup-main {
  padding: 0 !important;
}

.setup-main :deep(.v-container) {
  padding: 0 !important;
  margin: 0 !important;
  max-width: none !important;
}

/* Navigation drawer styling */

/* Global snackbar positioning - force viewport bottom positioning */
:deep(.v-overlay.v-snackbar__wrapper) {
  position: fixed !important;
  top: auto !important;
  bottom: 16px !important;
  left: 50% !important;
  right: auto !important;
  transform: translateX(-50%) !important;
  z-index: 9999 !important;
  width: auto !important;
  height: auto !important;
}

:deep(.v-snackbar.global-snackbar) {
  position: static !important;
  max-width: 90vw !important;
  margin: 0 auto !important;
}

/* Ensure snackbar success color is properly green */
:deep(.v-snackbar--variant-elevated.bg-success) {
  background-color: rgb(76, 175, 80) !important;
  color: white !important;
}

:deep(.v-snackbar--variant-elevated.bg-success .v-btn) {
  color: white !important;
}

/* Footer positioning to avoid snackbar overlap */
.footer-fixed {
  position: sticky !important;
  bottom: 0 !important;
  z-index: 1000 !important;
  margin-bottom: 0 !important;
}

/* Donation address styling */
.donation-address {
  color: rgb(255, 152, 0) !important;
  cursor: pointer;
  text-decoration: underline;
  font-family: 'Courier New', monospace;
  font-size: 0.75rem;
}

.donation-address:hover {
  color: rgb(255, 193, 7) !important;
}
:deep(.v-navigation-drawer) {
  background-color: var(--color-surface) !important;
  border-right: 1px solid var(--color-border-subtle);
}

:deep(.v-navigation-drawer .v-list-item) {
  color: var(--color-text-primary) !important;
}

:deep(.v-navigation-drawer .v-list-item-title) {
  color: var(--color-text-primary) !important;
  font-weight: var(--font-weight-semibold);
}

:deep(.v-navigation-drawer .v-list-item-subtitle) {
  color: var(--color-text-secondary) !important;
}

:deep(.v-navigation-drawer .v-list-item--active) {
  background-color: var(--color-primary-alpha-10) !important;
  color: var(--color-primary) !important;
}

:deep(.v-navigation-drawer .v-list-item--active .v-list-item-title) {
  color: var(--color-primary) !important;
}

:deep(.v-navigation-drawer .v-list-item:hover) {
  background-color: var(--color-surface-hover) !important;
}

:deep(.v-navigation-drawer .v-divider) {
  border-color: var(--color-border-subtle) !important;
}

/* App bar styling */
:deep(.v-app-bar) {
  background-color: var(--color-surface) !important;
  border-bottom: 1px solid var(--color-border-subtle);
  box-shadow: var(--shadow-1);
}

:deep(.v-app-bar .v-toolbar-title) {
  color: var(--color-text-primary) !important;
  font-weight: var(--font-weight-semibold);
}

:deep(.v-app-bar .v-btn) {
  color: var(--color-text-primary) !important;
}

/* Main content area */
:deep(.v-main) {
  background-color: var(--color-background) !important;
}

/* Override padding for setup route */
:deep(.v-main.setup-main) {
  padding-top: 0 !important;
}

:deep(.v-container) {
  background-color: transparent;
}

/* Dialog styling */
:deep(.v-dialog .v-card) {
  background-color: var(--color-surface-elevated) !important;
  border: 1px solid var(--color-border);
  box-shadow: var(--shadow-4);
}

:deep(.v-dialog .v-card-title) {
  background-color: var(--color-surface-secondary);
  border-bottom: 1px solid var(--color-border-subtle);
  color: var(--color-text-primary) !important;
  font-weight: var(--font-weight-semibold);
}

:deep(.v-dialog .v-card-text) {
  color: var(--color-text-primary) !important;
}

/* Form styling */
:deep(.v-text-field .v-field) {
  background-color: var(--color-surface-secondary) !important;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
}

:deep(.v-text-field .v-field:hover) {
  border-color: var(--color-primary);
}

:deep(.v-text-field .v-field--focused) {
  border-color: var(--color-primary) !important;
  box-shadow: var(--shadow-focus);
}

:deep(.v-text-field input) {
  color: var(--color-text-primary) !important;
}

:deep(.v-text-field .v-field__input::placeholder) {
  color: var(--color-text-hint) !important;
}

:deep(.v-select .v-field) {
  background-color: var(--color-surface-secondary) !important;
  border: 1px solid var(--color-border);
}

/* Button styling */
:deep(.v-btn) {
  font-weight: var(--font-weight-medium);
  transition: all var(--transition-fast);
  border-radius: var(--radius-md);
}

:deep(.v-btn:hover) {
  transform: translateY(-1px);
}

:deep(.v-btn--variant-elevated) {
  box-shadow: var(--shadow-1);
}

:deep(.v-btn--variant-elevated:hover) {
  box-shadow: var(--shadow-2);
}

/* Chip styling */
:deep(.v-chip) {
  font-weight: var(--font-weight-medium);
  border-radius: var(--radius-sm);
}

/* Snackbar styling handled globally in main.css */

/* Footer styling */
:deep(.v-footer) {
  background-color: var(--color-surface) !important;
  border-top: 1px solid var(--color-border-subtle);
  color: var(--color-text-secondary) !important;
  height: 64px !important;
  min-height: 64px !important;
  max-height: 64px !important;
  padding: 12px 16px !important;
  display: flex !important;
  align-items: center !important;
  box-sizing: border-box !important;
}

/* Ensure footer text sizing is consistent */
:deep(.v-footer .text-caption) {
  font-size: 12px !important;
  line-height: 1.4 !important;
}

/* Responsive footer adjustments */
@media (max-width: 768px) {
  :deep(.v-footer) {
    height: 64px !important;
    min-height: 64px !important;
    max-height: 64px !important;
    padding: 12px 16px !important;
  }
}

@media (max-width: 480px) {
  :deep(.v-footer) {
    height: 64px !important;
    min-height: 64px !important;
    max-height: 64px !important;
    padding: 8px 12px !important;
  }
  
  :deep(.v-footer .text-caption) {
    font-size: 11px !important;
  }
}

/* Standardized footer positioning and sizing */
.footer-fixed {
  position: relative !important;
  bottom: auto !important;
  left: auto !important;
  right: auto !important;
  width: 100% !important;
  z-index: auto !important;
  height: 64px !important;
  min-height: 64px !important;
  max-height: 64px !important;
  padding: 12px 16px !important;
  display: flex !important;
  align-items: center !important;
  box-sizing: border-box !important;
}

/* Ensure footer consistency across all screen sizes */
@media (max-width: 768px) {
  .footer-fixed {
    height: 64px !important;
    min-height: 64px !important;
    max-height: 64px !important;
    padding: 12px 16px !important;
  }
}

@media (max-width: 480px) {
  .footer-fixed {
    height: 64px !important;
    min-height: 64px !important;
    max-height: 64px !important;
    padding: 8px 12px !important;
  }
}

/* Easter egg hint styling */
.easter-egg-hint {
  cursor: help;
  transition: all var(--transition-fast);
  opacity: 0.7;
}

.easter-egg-hint:hover {
  opacity: 1;
  transform: scale(1.1);
}

.gaming-hint {
  font-size: var(--font-size-small);
  margin-left: var(--spacing-xs);
}

/* Accessibility improvements */
@media (prefers-reduced-motion: reduce) {
  :deep(.v-btn),
  .easter-egg-hint {
    transition: none;
    transform: none !important;
  }
  
  :deep(.v-btn:hover),
  .easter-egg-hint:hover {
    transform: none !important;
  }
}

/* Refresh button animation */
.refresh-spinning {
  animation: refresh-spin 1s linear infinite;
}

@keyframes refresh-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* High contrast mode support */
@media (prefers-contrast: high) {
  :deep(.v-navigation-drawer),
  :deep(.v-app-bar),
  :deep(.v-dialog .v-card) {
    border-width: 2px;
  }
  
  :deep(.v-btn) {
    border: 1px solid var(--color-text-primary);
  }
}

/* Accessibility improvements */
@media (prefers-reduced-motion: reduce) {
  .refresh-spinning {
    animation: none;
  }
  
  :deep(.v-btn),
  .easter-egg-hint {
    transition: none;
    transform: none !important;
  }
  
  :deep(.v-btn:hover),
  .easter-egg-hint:hover {
    transform: none !important;
  }
}

/* Donation address styling */
.donation-address {
  color: #F7931A !important; /* Bitcoin orange */
  text-decoration: underline;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.2s ease;
}

.donation-address:hover {
  color: #FF8C00 !important; /* Slightly brighter orange on hover */
  text-decoration: underline;
  opacity: 0.8;
}

.donation-address:active {
  transform: scale(0.98);
}

/* Ensure donation address is accessible */
@media (prefers-reduced-motion: reduce) {
  .donation-address {
    transition: none;
  }
  
  .donation-address:active {
    transform: none;
  }
}

/* Settings dialog actions visibility fix */
:deep(.settings-dialog-actions) {
  display: flex !important;
  justify-content: flex-end !important;
  align-items: center !important;
  padding: 16px 24px !important;
  min-height: 64px !important;
  border-top: 1px solid rgba(var(--v-border-color), 0.12);
  background-color: rgba(var(--v-theme-surface), 1) !important;
}

:deep(.settings-dialog-actions .v-btn) {
  margin-left: 8px !important;
  min-width: 80px !important;
}
</style>